# BasketCoach AI — Production Edition

Production-oriented Flutter + Supabase starter for a basketball coaching platform.

## Features
- Splash + onboarding
- Email/password authentication
- Production-style dashboard
- Teams, roster and player profiles
- Player assessment and skill trend screen
- Training library and quick AI prompts
- AI Coach chat
- Persistent conversations/messages
- Supabase cloud database
- Owner-based RLS
- Server-side AI backend
- Light/dark theme support
- App branding/icon placeholders

## Build
flutter pub get
flutter build apk --release

For Google Play:
flutter build appbundle --release

## Required secrets
Backend only:
SUPABASE_URL=https://cijldixlozgifuepcstj.supabase.co
SUPABASE_SERVICE_ROLE_KEY=...
OPENAI_API_KEY=...
OPENAI_MODEL=...

Never place service-role or OpenAI secrets in the Flutter app.
