import express from "express"; import cors from "cors"; import dotenv from "dotenv"; import OpenAI from "openai"; import {createClient} from "@supabase/supabase-js";
dotenv.config(); const app=express(); app.use(cors()); app.use(express.json({limit:"1mb"}));
const ai=new OpenAI({apiKey:process.env.OPENAI_API_KEY}); const sb=createClient(process.env.SUPABASE_URL,process.env.SUPABASE_SERVICE_ROLE_KEY);
const system=`You are BasketCoach AI, a professional Indonesian basketball coaching assistant. Give practical structured answers. Use supplied team/player/metric data and never invent missing statistics. Support training plans, progressive drills, player development, game plans, lineup concepts and match analysis.`;
app.get("/health",(_,r)=>r.json({ok:true,app:"BasketCoach AI Production"}));
app.post("/api/chat",async(req,res)=>{try{
 const token=(req.headers.authorization||"").replace("Bearer ","").trim(); if(!token)return res.status(401).json({error:"Authentication required"});
 const {data:u}=await sb.auth.getUser(token); if(!u?.user)return res.status(401).json({error:"Invalid session"}); const uid=u.user.id;
 const {message,history=[]}=req.body;if(!message)return res.status(400).json({error:"message required"});
 const {data:teams}=await sb.from("teams").select("id,name,category,coach,season").eq("owner_id",uid);const ids=(teams||[]).map(x=>x.id);
 let players=[],metrics=[];if(ids.length){const p=await sb.from("players").select("id,team_id,name,jersey_number,position,age,height_cm,weight_kg,notes").in("team_id",ids);players=p.data||[];if(players.length){const m=await sb.from("player_metrics").select("*").in("player_id",players.map(x=>x.id)).order("metric_date",{ascending:false});metrics=m.data||[];}}
 const context=`TEAMS ${JSON.stringify(teams||[])}\nPLAYERS ${JSON.stringify(players)}\nMETRICS ${JSON.stringify(metrics)}`;
 const messages=[{role:"system",content:system+"\nDATABASE:\n"+context},...history.slice(-10).map(x=>({role:x.role,content:x.content})),{role:"user",content:message}];
 const out=await ai.chat.completions.create({model:process.env.OPENAI_MODEL||"gpt-5.6-luna",messages});const reply=out.choices?.[0]?.message?.content||"Tidak ada jawaban.";
 res.json({reply});
}catch(e){console.error(e);res.status(500).json({error:"AI backend error"});}});
app.listen(process.env.PORT||3000,()=>console.log("BasketCoach AI production backend running"));
