import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:fl_chart/fl_chart.dart';

const supabaseUrl='https://cijldixlozgifuepcstj.supabase.co';
const publishableKey='sb_publishable_3y1xnyXYnLTx7M_m33q4Kw_MJ2fLvx0';
const apiBaseUrl='https://cijldixlozgifuepcstj.supabase.co/functions/v1/basketcoach-ai';
final db=Supabase.instance.client;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url:supabaseUrl, anonKey:publishableKey);
  runApp(const App());
}

class App extends StatelessWidget{
 const App({super.key});
 Widget build(BuildContext c)=>MaterialApp(
  debugShowCheckedModeBanner:false,title:'BasketCoach AI',
  theme:ThemeData(useMaterial3:true,colorSchemeSeed:Colors.deepOrange,brightness:Brightness.light),
  darkTheme:ThemeData(useMaterial3:true,colorSchemeSeed:Colors.deepOrange,brightness:Brightness.dark),
  home:const Gate());
}

class Gate extends StatelessWidget{
 const Gate({super.key});
 Widget build(BuildContext c)=>StreamBuilder<AuthState>(
  stream:db.auth.onAuthStateChange,
  builder:(_,__)=>db.auth.currentSession==null?const Auth():const MainShell());
}

class Auth extends StatefulWidget{const Auth({super.key});State<Auth>createState()=>_AuthState();}
class _AuthState extends State<Auth>{
 final e=TextEditingController(),p=TextEditingController(); bool signup=false,busy=false; String? err;
 Future go()async{setState(()=>busy=true);try{if(signup){await db.auth.signUp(email:e.text.trim(),password:p.text);}else{await db.auth.signInWithPassword(email:e.text.trim(),password:p.text);}}catch(x){setState(()=>err=x.toString());}setState(()=>busy=false);}
 Widget build(BuildContext c)=>Scaffold(body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(28),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:440),child:Column(children:[
  const Icon(Icons.sports_basketball,size:80),const SizedBox(height:10),
  const Text('BasketCoach AI',style:TextStyle(fontSize:32,fontWeight:FontWeight.bold)),
  const Text('Your basketball coaching assistant',textAlign:TextAlign.center),const SizedBox(height:28),
  TextField(controller:e,decoration:const InputDecoration(labelText:'Email',border:OutlineInputBorder())),
  const SizedBox(height:12),TextField(controller:p,obscureText:true,decoration:const InputDecoration(labelText:'Password',border:OutlineInputBorder())),
  if(err!=null)Padding(padding:const EdgeInsets.all(8),child:Text(err!,style:const TextStyle(color:Colors.red))),
  const SizedBox(height:12),SizedBox(width:double.infinity,child:FilledButton(onPressed:busy?null:go,child:Text(signup?'Daftar':'Masuk'))),
  TextButton(onPressed:()=>setState(()=>signup=!signup),child:Text(signup?'Sudah punya akun? Masuk':'Buat akun baru'))
 ])))));
}
}

class MainShell extends StatefulWidget{const MainShell({super.key});State<MainShell>createState()=>_MainShellState();}
class _MainShellState extends State<MainShell>{
 int i=0; final pages=const[Home(),Chat(),Teams(),Players()];
 Widget build(BuildContext c)=>Scaffold(body:pages[i],bottomNavigationBar:NavigationBar(selectedIndex:i,onDestinationSelected:(x)=>setState(()=>i=x),destinations:const[
  NavigationDestination(icon:Icon(Icons.dashboard_outlined),selectedIcon:Icon(Icons.dashboard),label:'Beranda'),
  NavigationDestination(icon:Icon(Icons.auto_awesome_outlined),selectedIcon:Icon(Icons.auto_awesome),label:'AI Coach'),
  NavigationDestination(icon:Icon(Icons.groups_outlined),selectedIcon:Icon(Icons.groups),label:'Tim'),
  NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Pemain'),
 ]));
}

class Home extends StatelessWidget{
 const Home({super.key});
 final menus=const[['Program Latihan',Icons.fitness_center],['Ball Handling',Icons.sports_basketball],['Passing',Icons.compare_arrows],['Finishing',Icons.directions_run],['Shooting',Icons.track_changes],['Defense',Icons.shield_outlined],['How to Play',Icons.psychology],['Game Plan',Icons.assignment]];
 Widget build(BuildContext c)=>SafeArea(child:CustomScrollView(slivers:[
  SliverAppBar.large(title:const Text('BasketCoach AI'),actions:[IconButton(onPressed:()=>db.auth.signOut(),icon:const Icon(Icons.logout))]),
  SliverPadding(padding:const EdgeInsets.all(16),sliver:SliverToBoxAdapter(child:Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
   const Text('Coach Dashboard',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),const SizedBox(height:8),
   const Text('Kelola tim, kembangkan pemain, dan gunakan AI untuk menyusun latihan.'),
   const SizedBox(height:16),FutureBuilder(future:db.from('teams').select('id').count(CountOption.exact),builder:(_,s)=>Text('Tim aktif: ${s.data?.count??0}',style:const TextStyle(fontWeight:FontWeight.w600)))
  ])))),
  SliverPadding(padding:const EdgeInsets.all(16),sliver:SliverGrid(delegate:SliverChildBuilderDelegate((_,n)=>Card(child:InkWell(onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>Chat(prefill:menus[n][0] as String))),child:Padding(padding:const EdgeInsets.all(14),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(menus[n][1] as IconData,size:30),const SizedBox(height:8),Text(menus[n][0] as String,textAlign:TextAlign.center)])))),childCount:menus.length),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,crossAxisSpacing:12,mainAxisSpacing:12,childAspectRatio:1.2)))
 ]));
}

class Chat extends StatefulWidget{final String? prefill;const Chat({super.key,this.prefill});State<Chat>createState()=>_ChatState();}
class _ChatState extends State<Chat>{
 final ctl=TextEditingController();bool busy=false;final m=<Map<String,String>>[{'role':'assistant','content':'Halo Coach! Saya siap membantu latihan, development pemain, statistik, dan game plan.'}];
 void initState(){super.initState();if(widget.prefill!=null)ctl.text='Buatkan ${widget.prefill!.toLowerCase()} untuk tim saya.';}
 Future send()async{final q=ctl.text.trim();if(q.isEmpty||busy)return;setState((){m.add({'role':'user','content':q});busy=true;});ctl.clear();try{
  final r=await http.post(Uri.parse(apiBaseUrl),headers:{'Content-Type':'application/json','Authorization':'Bearer ${db.auth.currentSession?.accessToken??''}'},body:jsonEncode({'message':q,'history':m}));
  final d=jsonDecode(r.body);setState(()=>m.add({'role':'assistant','content':d['reply']?.toString()??'Tidak ada jawaban.'}));
 }catch(_){setState(()=>m.add({'role':'assistant','content':'Backend AI belum aktif. Jalankan backend dan cek API base URL.'}));}setState(()=>busy=false);}
 Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('AI Coach')),body:Column(children:[
  Expanded(child:ListView.builder(padding:const EdgeInsets.all(14),itemCount:m.length,itemBuilder:(_,i){final u=m[i]['role']=='user';return Align(alignment:u?Alignment.centerRight:Alignment.centerLeft,child:Container(constraints:const BoxConstraints(maxWidth:360),margin:const EdgeInsets.symmetric(vertical:5),padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:u?Theme.of(c).colorScheme.primaryContainer:Theme.of(c).colorScheme.surfaceContainerHighest,borderRadius:BorderRadius.circular(18)),child:SelectableText(m[i]['content']!)));})),
  if(busy)const LinearProgressIndicator(),SafeArea(child:Padding(padding:const EdgeInsets.all(10),child:Row(children:[Expanded(child:TextField(controller:ctl,maxLines:4,minLines:1,decoration:const InputDecoration(hintText:'Tanya BasketCoach AI...',border:OutlineInputBorder()))),const SizedBox(width:8),IconButton.filled(onPressed:busy?null:send,icon:const Icon(Icons.send))])))
 ]));
}

class Teams extends StatefulWidget{const Teams({super.key});State<Teams>createState()=>_TeamsState();}
class _TeamsState extends State<Teams>{
 Future<List<Map<String,dynamic>>> load()async=>db.from('teams').select().order('created_at',ascending:false);
 Future add()async{final n=TextEditingController(),cat=TextEditingController(),coach=TextEditingController();await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Tambah Tim'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Nama tim')),TextField(controller:cat,decoration:const InputDecoration(labelText:'Kategori')),TextField(controller:coach,decoration:const InputDecoration(labelText:'Coach'))]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Batal')),FilledButton(onPressed:()async{if(n.text.trim().isNotEmpty)await db.from('teams').insert({'name':n.text.trim(),'category':cat.text.trim(),'coach':coach.text.trim(),'owner_id':db.auth.currentUser!.id});if(context.mounted){Navigator.pop(context);setState((){});}},child:const Text('Simpan'))]));}
 Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Tim Saya')),floatingActionButton:FloatingActionButton(onPressed:add,child:const Icon(Icons.add)),body:FutureBuilder(future:load(),builder:(_,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());final a=s.data!;if(a.isEmpty)return const Center(child:Text('Belum ada tim.'));return ListView.builder(padding:const EdgeInsets.all(16),itemCount:a.length,itemBuilder:(_,i){final t=a[i];return Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.groups)),title:Text(t['name']),subtitle:Text('${t['category']??''} • ${t['coach']??''}')));});}));
}
class Players extends StatefulWidget{const Players({super.key});State<Players>createState()=>_PlayersState();}
class _PlayersState extends State<Players>{
 Future<List<Map<String,dynamic>>> load()async=>db.from('players').select('*,teams(name)').order('created_at',ascending:false);
 Future<List<Map<String,dynamic>>> ts()async=>db.from('teams').select('id,name').order('name');
 Future add()async{final teams=await ts();if(!mounted)return;if(teams.isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Buat tim terlebih dahulu.')));return;}String tid=teams.first['id'];final n=TextEditingController(),pos=TextEditingController(),j=TextEditingController();await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Tambah Pemain'),content:Column(mainAxisSize:MainAxisSize.min,children:[DropdownButtonFormField<String>(value:tid,items:teams.map((x)=>DropdownMenuItem(value:x['id'].toString(),child:Text(x['name']))).toList(),onChanged:(v){if(v!=null)tid=v;}),TextField(controller:n,decoration:const InputDecoration(labelText:'Nama')),TextField(controller:j,decoration:const InputDecoration(labelText:'No. Jersey'),keyboardType:TextInputType.number),TextField(controller:pos,decoration:const InputDecoration(labelText:'Posisi'))]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Batal')),FilledButton(onPressed:()async{if(n.text.trim().isNotEmpty)await db.from('players').insert({'team_id':tid,'name':n.text.trim(),'jersey_number':int.tryParse(j.text),'position':pos.text.trim()});if(context.mounted){Navigator.pop(context);setState((){});}},child:const Text('Simpan'))]));}
 Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Pemain')),floatingActionButton:FloatingActionButton(onPressed:add,child:const Icon(Icons.add)),body:FutureBuilder(future:load(),builder:(_,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());final a=s.data!;if(a.isEmpty)return const Center(child:Text('Belum ada pemain.'));return ListView.builder(padding:const EdgeInsets.all(16),itemCount:a.length,itemBuilder:(_,i){final p=a[i];final team=p['teams'] is Map?p['teams']['name']:'-';return Card(child:ListTile(onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>PlayerDetail(player:p))),leading:CircleAvatar(child:Text('${p['jersey_number']??'-'}')),title:Text(p['name']),subtitle:Text('${p['position']??'-'} • $team')));});}));
}
class PlayerDetail extends StatelessWidget{
 final Map player;const PlayerDetail({super.key,required this.player});
 Future<List<Map<String,dynamic>>> metrics()=>db.from('player_metrics').select().eq('player_id',player['id']).order('metric_date');
 Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Text(player['name'])),body:FutureBuilder(future:metrics(),builder:(_,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());final a=s.data!;final latest=a.isEmpty?null:a.last;return ListView(padding:const EdgeInsets.all(16),children:[
  Card(child:ListTile(title:Text(player['name'],style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),subtitle:Text('Posisi: ${player['position']??'-'} • Jersey: ${player['jersey_number']??'-'}'))),
  const SizedBox(height:12),const Text('Skill Assessment',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:8),
  if(latest!=null)...['ball_handling','passing','finishing','shooting','defense','decision_making','fitness'].map((k)=>Padding(padding:const EdgeInsets.symmetric(vertical:4),child:LinearProgressIndicator(value:((latest[k]??0)as num)/10,minHeight:10))),
  const SizedBox(height:18),if(a.length>=2)SizedBox(height:220,child:LineChart(LineChartData(titlesData:const FlTitlesData(show:false),lineBarsData:[LineChartBarData(spots:[for(int i=0;i<a.length;i++)FlSpot(i.toDouble(),((a[i]['shooting']??0)as num).toDouble())],isCurved:true)])))
 ]);}));}
}
