-- Production hardening already applied to the connected project:
-- teams.owner_id -> auth.users(id)
-- RLS policies restrict teams and child data to the authenticated team owner.
-- Verify with:
select table_name, row_security
from information_schema.tables
where table_schema='public'
and table_name in ('teams','players','player_metrics','conversations','messages');
